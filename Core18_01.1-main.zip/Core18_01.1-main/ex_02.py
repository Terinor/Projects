age10 = 30

print(age10 + 20)

human_age = 50

HUMAN_AGE = 100

name = "\"Bill\"" + '"Bill"'

print(name)

user_str = None

# result = float(user_str) + 10
# print(result)


print(bool(user_str))
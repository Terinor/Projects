"""boolean"""

is_admin = True
is_user = False

print(True + True + True)

number1 = 30
number2 = 40

print(number1 != number2)
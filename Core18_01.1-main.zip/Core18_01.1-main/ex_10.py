user_input = input(">>>")

print(type(int(user_input)))
"""+, -, *, /, %, //, **"""

number1 = 23.1
number2 = 45

print(number1 + number2)
print(number1 - number2)
print(number1 * number2)
print(number1 / number2)

number3 = 14
number4 = 5

print(number3 % number4)
print(number3 // number4)


number5 = 9
pow_ = -2

print(number5 ** pow_)
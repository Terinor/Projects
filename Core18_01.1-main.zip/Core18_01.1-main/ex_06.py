number1 = 123
number2 = None

print(number1 + number2)
number1 = 1
number10 = 10
number1000 = 1_000
big_number = 1_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0

print(big_number + number1000)

number1_1 = 1.1
number10_5 = 10.5

print(number1_1)

complex_number = 3.2 + 5j

print(complex_number)




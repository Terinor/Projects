"""string"""

greeting = "Hello Python"

print(greeting)

dot = "."

# print((greeting + dot * 3) * 3.14)

print(greeting + str(3.14))

name = "Jill"
age = 10
new_age = 10

print(F"My name is {name}, i'm {age + new_age} old")

print('' > 'test')

print(".\n.\n.")
